     public class Livr {
     public int id;
     public String title;
     public String author;

     public Livr(int id, String title, String author) {
         this.id = id;
         this.title = title;
         this.author = author;
     }

     public int getId() {
         return id;
     }

     public String getTitle() {
          return title;
     }
     public String getAuthor() {
             return author;
         }

         @Override
         public String toString() {
             return "ID: " + id + ", Title: " + title + ", Author: " + author;
         }
     }
 

